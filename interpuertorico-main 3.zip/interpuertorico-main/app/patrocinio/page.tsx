import { redirect } from "next/navigation"

export default function PatrocinioPage() {
  redirect("/#patrocinio")
}
